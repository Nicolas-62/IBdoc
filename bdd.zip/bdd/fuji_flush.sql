use fuji_flush;
insert into joueur(nom, prenom, password) values('lourdel', 'nicolas', 'azerty');
insert into joueur(nom, prenom, password) values('dupond', 'patrick', 'azerty');
insert into joueur(nom, prenom, password) values('martin', 'jacques', 'azerty');
insert into partie(dateCrea) values('20191028');

select * from joueur;
delete from joueur where id = 9;
truncate table joueur;
desc Partie;


